import React from "react";
import { Navbar } from "@/components/Navbar";
import { motion } from "framer-motion";
import { FaInstagram, FaWhatsapp, FaPhone, FaMapMarkerAlt, FaEnvelope } from "react-icons/fa";

import heroBg from "@assets/83da4aab6a972a7efb1cfcdfb321a5bc_1779013351274.jpg";
import profileImg from "@assets/Screenshot_20260517-160735_Photos_1779014432069.png";

import port1 from "@assets/476494ca65a87b5aceab27a1ec8154c6_1779013351228.jpg";
import port2 from "@assets/2a1f30ea9276dceefe7f25a57b923a77_1779013351249.jpg";
import port3 from "@assets/8bc60ade553d343d4cbe90d7b767289f_1779013351261.jpg";
import port4 from "@assets/83da4aab6a972a7efb1cfcdfb321a5bc_1779013351274.jpg";
import port5 from "@assets/f89d99759b539ed7a65c7951587e9d61_1779013351286.jpg";
import port6 from "@assets/cc9122d82949941672740de0eda52c02_1779013351299.jpg";
import port7 from "@assets/IMG-20260517-WA0003_1779013351325.jpg";
import port8 from "@assets/IMG-20260517-WA0007_1779013351337.jpg";

const services = [
  { title: "Wedding Photography", desc: "Candid, traditional, pre-wedding, cinematic highlights" },
  { title: "Events Photography", desc: "Corporate galas, conferences, cultural meets" },
  { title: "Baby Photoshoot", desc: "Newborn, maternity, toddler portraits" },
  { title: "Corporate Shoot", desc: "Headshots, team branding, business events" },
  { title: "Birthday Shoot", desc: "Vibrant celebrations, milestone storytelling" },
  { title: "Anniversary Shoot", desc: "Romantic couple portraits" },
  { title: "Gimbal Cinematic", desc: "Smooth gimbal video & hyperlapse, BTS & highlight reels" },
];

const portfolioImages = [
  { src: port1, alt: "Aerial circular bridal shot", span: "col-span-1 md:col-span-2 row-span-2" },
  { src: port2, alt: "Aerial paisley lehenga bridal", span: "col-span-1 row-span-1" },
  { src: port3, alt: "Close-up bride with maang tikka", span: "col-span-1 row-span-1" },
  { src: port4, alt: "Editorial Bride dark moody shot", span: "col-span-1 md:col-span-2 row-span-1" },
  { src: port5, alt: "Bride from behind with lanterns", span: "col-span-1 row-span-2" },
  { src: port6, alt: "Dramatic bride with dupatta", span: "col-span-1 row-span-1" },
  { src: port7, alt: "Full bridal look with chandelier", span: "col-span-1 row-span-1" },
  { src: port8, alt: "Wedding couple shot", span: "col-span-1 md:col-span-2 row-span-2" },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />

      {/* Hero Section */}
      <section id="home" className="relative h-screen w-full flex items-center justify-center pt-20">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroBg} 
            alt="Hero Cinematic Background" 
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/30" />
        </div>
        
        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            <span className="text-secondary tracking-[0.3em] uppercase text-sm mb-4 block font-medium">
              By Rishav Raj
            </span>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold mb-6 text-foreground drop-shadow-2xl">
              The Picture <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Palace</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground font-light mb-10 max-w-2xl mx-auto">
              Every frame is a story. Premium wedding and cinematic events photography in Teghra, Bihar.
            </p>
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="#portfolio"
              className="inline-block px-10 py-4 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground font-serif text-lg hover:shadow-[0_0_30px_rgba(196,30,58,0.5)] transition-all duration-300 rounded-sm"
            >
              Explore the Gallery
            </motion.a>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 md:py-32 relative bg-background">
        <div className="container mx-auto px-6 md:px-12">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
              className="w-full lg:w-1/2"
            >
              <div className="relative aspect-[4/5] w-full max-w-md mx-auto lg:mx-0">
                <div className="absolute inset-0 bg-gradient-to-tr from-primary to-secondary rounded-sm transform translate-x-4 translate-y-4 opacity-50 blur-sm"></div>
                <img 
                  src={profileImg} 
                  alt="Rishav Raj - Lead Photographer" 
                  className="w-full h-full object-cover relative z-10 rounded-sm shadow-2xl grayscale-[20%] contrast-125"
                />
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="w-full lg:w-1/2 space-y-8"
            >
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground">
                Bold. Moody. <span className="text-secondary italic">Unforgettable.</span>
              </h2>
              <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary"></div>
              <p className="text-xl md:text-2xl font-serif text-muted-foreground leading-relaxed">
                At The Picture Palace, we aren't here for cheesy smiles or predictable backdrops. We are here to find your edge.
              </p>
              <p className="text-base text-muted-foreground leading-relaxed font-light">
                Whether you need a headshot that means business or a portrait that feels like a movie still, we use dramatic lighting and fearless direction to reveal the version of you that usually hides just beneath the surface.
              </p>
              <p className="text-lg font-medium text-foreground pt-4">
                Ready to look like the main character you are?
              </p>
              <div className="pt-4">
                <p className="font-serif text-2xl text-secondary">Rishav Raj</p>
                <p className="text-sm text-muted-foreground uppercase tracking-widest mt-1">Lead Photographer & Director</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 md:py-32 bg-card relative border-y border-border">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-background to-background pointer-events-none"></div>
        <div className="container mx-auto px-6 md:px-12 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">Our Services</h2>
            <div className="w-24 h-1 bg-secondary mx-auto mb-6"></div>
            <p className="text-muted-foreground max-w-2xl mx-auto font-light">
              We bring cinematic vision to every scale of event. From grand weddings to intimate portraits.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group p-8 border border-border bg-background/50 hover:bg-card hover:border-primary/50 transition-all duration-300 relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-secondary transform origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
                <h3 className="text-2xl font-serif font-semibold mb-4 text-foreground group-hover:text-secondary transition-colors">{service.title}</h3>
                <p className="text-muted-foreground font-light leading-relaxed">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-24 md:py-32 bg-background">
        <div className="container mx-auto px-6 md:px-12">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-6"
          >
            <div>
              <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">The Gallery</h2>
              <div className="w-24 h-1 bg-primary"></div>
            </div>
            <p className="text-muted-foreground max-w-md font-light text-right hidden md:block">
              A curated selection of our finest cinematic moments. Hover to explore the details.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 auto-rows-[300px] gap-4">
            {portfolioImages.map((img, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className={`relative overflow-hidden group ${img.span} bg-card rounded-sm`}
              >
                <img 
                  src={img.src} 
                  alt={img.alt} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-hover:rotate-1"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                  <p className="text-foreground font-serif text-lg translate-y-4 group-hover:translate-y-0 transition-transform duration-300">{img.alt}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 md:py-32 bg-card border-t border-border relative">
        <div className="container mx-auto px-6 md:px-12">
          <div className="max-w-4xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">Book Your Shoot</h2>
              <div className="w-24 h-1 bg-secondary mx-auto mb-8"></div>
              <p className="text-xl text-muted-foreground font-light">
                Let's create something unforgettable together.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 bg-background p-8 md:p-12 border border-border shadow-2xl relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 blur-3xl rounded-full"></div>
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-secondary/10 blur-3xl rounded-full"></div>

              <div className="space-y-8 relative z-10">
                <h3 className="text-2xl font-serif font-bold mb-6">Get in Touch</h3>
                
                <div className="flex items-start gap-4">
                  <div className="mt-1 p-3 bg-card border border-border rounded-full text-secondary">
                    <FaPhone size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground uppercase tracking-wider mb-1">Phone</p>
                    <a href="tel:+919135519878" className="text-lg font-medium hover:text-primary transition-colors">+91 91355 19878</a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="mt-1 p-3 bg-card border border-border rounded-full text-green-500">
                    <FaWhatsapp size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground uppercase tracking-wider mb-1">WhatsApp</p>
                    <a href="https://wa.me/919135519878" target="_blank" rel="noopener noreferrer" className="text-lg font-medium hover:text-primary transition-colors">Chat with us</a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="mt-1 p-3 bg-card border border-border rounded-full text-primary">
                    <FaEnvelope size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground uppercase tracking-wider mb-1">Email</p>
                    <a href="mailto:thepicturespalace@gmail.com" className="text-lg font-medium hover:text-primary transition-colors">thepicturespalace@gmail.com</a>
                  </div>
                </div>
              </div>

              <div className="space-y-8 relative z-10">
                <h3 className="text-2xl font-serif font-bold mb-6">Visit Us</h3>

                <div className="flex items-start gap-4">
                  <div className="mt-1 p-3 bg-card border border-border rounded-full text-secondary">
                    <FaMapMarkerAlt size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground uppercase tracking-wider mb-1">Location</p>
                    <a href="https://maps.app.goo.gl/8fwmV42LRyWJhkMR6?g_st=ac" target="_blank" rel="noopener noreferrer" className="text-lg font-medium hover:text-primary transition-colors block">
                      The Picture Palace<br/>
                      Teghra, Begusarai<br/>
                      Bihar - 851133
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="mt-1 p-3 bg-card border border-border rounded-full text-primary">
                    <FaInstagram size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground uppercase tracking-wider mb-1">Instagram</p>
                    <a href="https://www.instagram.com/risav_90?igsh=NHdvOHVvcW44cWN5" target="_blank" rel="noopener noreferrer" className="text-lg font-medium hover:text-primary transition-colors">@risav_90</a>
                  </div>
                </div>

                <div className="pt-4 border-t border-border">
                  <p className="text-sm text-muted-foreground mb-2">Hours:</p>
                  <p className="font-medium">Mon-Sat 10AM - 7PM</p>
                  <p className="font-medium">Sun by appointment</p>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12">
        <div className="container mx-auto px-6 md:px-12 text-center">
          <h2 className="text-3xl font-serif font-bold mb-6 text-foreground">The Picture Palace</h2>
          <div className="flex justify-center gap-6 mb-8">
            <a href="https://www.instagram.com/risav_90?igsh=NHdvOHVvcW44cWN5" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-secondary transition-colors p-2 hover:bg-card rounded-full">
              <FaInstagram size={24} />
            </a>
            <a href="https://wa.me/919135519878" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-green-500 transition-colors p-2 hover:bg-card rounded-full">
              <FaWhatsapp size={24} />
            </a>
          </div>
          <p className="text-muted-foreground font-light text-sm">
            &copy; {new Date().getFullYear()} The Picture Palace. All rights reserved.
          </p>
          <p className="text-muted-foreground/50 font-light text-xs mt-2">
            Teghra, Begusarai, Bihar.
          </p>
          <p className="text-muted-foreground/40 font-light text-xs mt-4">
            Website created by Satyam Saini
          </p>
        </div>
      </footer>
    </div>
  );
}
